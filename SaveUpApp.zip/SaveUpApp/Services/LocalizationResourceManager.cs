﻿using System.ComponentModel;
using System.Globalization;
using System.Resources;
// NAMESPACE anpassen, falls du es woanders hast:
using SaveUpApp.Resources.Strings;

namespace SaveUpApp.Services
{
    /// <summary>
    /// Beispiel-Klasse für Mehrsprachigkeit (Localization) mit Nullability-Fixes.
    /// </summary>
    public class LocalizationResourceManager : INotifyPropertyChanged
    {
        // Static-Feld darf NULL sein, bis wir es zum ersten Mal brauchen:
        private static LocalizationResourceManager? _instance = null;

        // Statischer Zugriff auf dieselbe Instanz:
        public static LocalizationResourceManager Instance
            => _instance ??= new LocalizationResourceManager();

        private readonly ResourceManager _resourceManager;
        private CultureInfo _currentCulture;

        // Das Event darf NULL sein, solange niemand darauf subscribed:
        public event PropertyChangedEventHandler? PropertyChanged;

        // Indexer zum Abfragen von Strings, z.B. loc["HomeWelcome"]
        public string this[string text] => GetValue(text);

        // Privater Konstruktor, damit nur Instance sie erzeugt
        private LocalizationResourceManager()
        {
            // "AppResources" ist deine .resx Resource
            _resourceManager = AppResources.ResourceManager;
            _currentCulture = CultureInfo.CurrentUICulture;
        }

        public string GetValue(string text)
        {
            if (string.IsNullOrEmpty(text)) return string.Empty;
            return _resourceManager.GetString(text, _currentCulture) ?? text;
        }

        public void SetCulture(CultureInfo culture)
        {
            _currentCulture = culture;
            // Signalisiert der UI, dass sich alle Bindungen geändert haben
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(null));
        }
    }
}
