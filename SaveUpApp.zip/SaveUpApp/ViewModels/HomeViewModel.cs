﻿namespace SaveUpApp.ViewModels
{
    public class HomeViewModel
    {
        // Nur als Platzhalter, falls du etwas binden willst
        // z.B. public string WelcomeText { get; set; } = "Willkommen bei SaveUp!";
    }
}
