﻿using System.Collections.ObjectModel;
using System.Linq;
using Microcharts;       
using SkiaSharp;
using SaveUpApp.Models;

namespace SaveUpApp.ViewModels
{
    public class ChartViewModel
    {
        private readonly ObservableCollection<Product> _products;

        // Non-nullable: sofort initialisieren (null!) oder direkt ein leeres DonutChart anlegen
        public Chart ProductChart { get; private set; } = null!;

        public ChartViewModel(ObservableCollection<Product> products)
        {
            _products = products;
            BuildChart();
        }

        private void BuildChart()
        {
            // ACHTUNG: Bei neueren Microcharts-Versionen heißt es "ChartEntry" (nicht "Entry")
            // und der DonutChart erwartet IEnumerable<ChartEntry>.
            var entries = _products.Select((p, index) => new ChartEntry((float)p.Price)
            {
                Label = p.Description ?? "",
                ValueLabel = p.Price.ToString("F2"),
                Color = GetColor(index)
            })
            .ToList(); // => List<ChartEntry>, passt dann zu DonutChart.Entries

            ProductChart = new DonutChart()
            {
                Entries = entries,     // DonutChart.Entries = IEnumerable<ChartEntry>
                HoleRadius = 0.5f,
                LabelTextSize = 32,
            };
        }

        private SKColor GetColor(int index)
        {
            // Farbenpool
            SKColor[] colors = new SKColor[]
            {
                SKColors.Red,
                SKColors.Green,
                SKColors.Blue,
                SKColors.Orange,
                SKColors.Purple,
                SKColors.Teal,
                SKColors.Brown
            };
            return colors[index % colors.Length];
        }
    }
}
