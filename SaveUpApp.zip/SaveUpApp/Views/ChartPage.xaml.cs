﻿using SaveUpApp.ViewModels;

namespace SaveUpApp.Views
{
    public partial class ChartPage : ContentPage
    {
        private ChartViewModel _viewModel;

        public ChartPage()
        {
            InitializeComponent();
            _viewModel = new ChartViewModel(AppShell.SharedProducts);
            BindingContext = _viewModel;
        }
    }
}
