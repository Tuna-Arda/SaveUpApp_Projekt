﻿using SaveUpApp.ViewModels;

namespace SaveUpApp.Views;

public partial class HomePage : ContentPage
{
    private HomeViewModel _viewModel;

    public HomePage()
    {
        InitializeComponent();
        _viewModel = new HomeViewModel();
        BindingContext = _viewModel;
    }

    private async void OnAddProductClicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync(nameof(AddProductPage));
        await Shell.Current.GoToAsync(nameof(ChartPage));
    }

    private async void OnShowListClicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync(nameof(ListPage));
        var loc = SaveUpApp.Services.LocalizationResourceManager.Instance;
        var currentCulture = System.Globalization.CultureInfo.CurrentUICulture.TwoLetterISOLanguageName;

        if (currentCulture == "en")
            loc.SetCulture(new System.Globalization.CultureInfo("de"));
        else
            loc.SetCulture(new System.Globalization.CultureInfo("en"));


        await Shell.Current.GoToAsync(nameof(ChartPage));
    }
    private async void OnShowChartClicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync(nameof(ChartPage));
    }
}
